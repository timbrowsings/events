# TASEventManager and TASEventKOTH fixed source bundle

This archive contains the revised unpacked script sources, profile configuration templates, and the original binarized TASEventManager config.bin. The scripts are not compiled into PBOs. Build them with the DayZ Workbench/Addon Builder before deployment and test on a staging server.

The profile_files folder intentionally excludes KOTHlastEvent.json and event/server logs. Preserve the server's existing runtime state and logs; copy or merge only the config files you intend to use.

GasRaidSiren remains a separate optional mod. The event mod spawns vanilla ContaminatedArea_Dynamic zones, so GasRaidSiren's class patch supplies its flare/siren effects when installed on the server and clients.
