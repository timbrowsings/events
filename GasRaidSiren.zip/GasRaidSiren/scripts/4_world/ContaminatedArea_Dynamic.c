
modded class ContaminatedArea_Dynamic : EffectArea
{
	EffectSound 			m_AmbientSound;
	const string			SOUND = "GasAlarm_SoundSet";
	
	override void PlayFlareVFX()
	{
		if ( GetGame().IsClient() || ( GetGame().IsServer() && !GetGame().IsMultiplayer() ) )
		{
			// We spawn locally the dummy object which will be used to move and manage the particle
			DynamicArea_Flare dummy = DynamicArea_Flare.Cast( GetGame().CreateObjectEx( "DynamicArea_Flare", m_OffsetPos, ECE_SETUP | ECE_LOCAL ) );
			
			// We add some light to reinforce the effect
			m_FlareLight = FlareLightContamination.Cast(ScriptedLightBase.CreateLight( FlareLightContamination, m_OffsetPos ));
			
			if ( !GetGame().IsDedicatedServer() )
			{
				PlaySoundSet( m_AmbientSound, SOUND, 0, 0 );
			}
		}
	}
}